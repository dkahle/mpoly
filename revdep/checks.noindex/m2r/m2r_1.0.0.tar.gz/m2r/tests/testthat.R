library(testthat)
library(m2r)

test_check("m2r")
